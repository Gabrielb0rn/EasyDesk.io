// scripts.js

document.querySelector('.login-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Login realizado com sucesso!');
});
